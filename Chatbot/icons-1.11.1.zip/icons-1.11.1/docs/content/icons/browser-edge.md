---
title: Browser Edge
categories:
  - Brand
tags:
  - microsoft
  - webkit
added: 1.10.0
---
