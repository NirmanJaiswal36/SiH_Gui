---
title: Box fill
categories:
  - Real world
tags:
  - cardboard
  - package
---
